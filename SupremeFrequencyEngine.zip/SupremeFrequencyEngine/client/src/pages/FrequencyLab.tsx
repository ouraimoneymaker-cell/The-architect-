import React, { useState } from 'react';
import { MOCK_FREQUENCIES, FrequencyConfig } from '@/lib/mock-data';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Plus, Edit2, Play, Trash2, Sliders } from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function FrequencyLab() {
  const [configs, setConfigs] = useState<FrequencyConfig[]>(MOCK_FREQUENCIES);
  const [editingConfig, setEditingConfig] = useState<FrequencyConfig | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingConfig) {
      if (configs.find(c => c.id === editingConfig.id)) {
         setConfigs(configs.map(c => c.id === editingConfig.id ? editingConfig : c));
         toast({ title: "Configuration Updated", description: `${editingConfig.name} has been modified.` });
      } else {
         setConfigs([...configs, { ...editingConfig, id: Date.now() }]);
         toast({ title: "Configuration Created", description: `${editingConfig.name} has been added.` });
      }
      setIsDialogOpen(false);
      setEditingConfig(null);
    }
  };

  const openNewConfig = () => {
    setEditingConfig({
      id: 0,
      name: "New Protocol",
      description: "",
      base_frequency: 783,
      mod_frequency: 4000,
      carrier_frequency: 2712000,
      voltage: 50000,
      current: 10,
      is_active: false
    });
    setIsDialogOpen(true);
  };

  const openEditConfig = (config: FrequencyConfig) => {
    setEditingConfig({...config});
    setIsDialogOpen(true);
  };

  const deleteConfig = (id: number) => {
    setConfigs(configs.filter(c => c.id !== id));
    toast({ title: "Deleted", description: "Configuration removed.", variant: "destructive" });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Frequency Lab</h1>
          <p className="text-muted-foreground">Configure and manage scalar wave protocols.</p>
        </div>
        <Button onClick={openNewConfig} className="bg-secondary hover:bg-secondary/80 text-white">
          <Plus className="mr-2 h-4 w-4" /> Create Protocol
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {configs.map((config) => (
          <Card key={config.id} className="bg-card/50 border-white/10 backdrop-blur-sm hover:border-primary/50 transition-all group relative overflow-hidden">
             <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl font-bold text-white">{config.name}</CardTitle>
                {config.is_active && <Badge className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30">Active</Badge>}
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2 h-10">{config.description}</p>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-1">
                  <span className="text-muted-foreground text-xs uppercase tracking-wider">Base Freq</span>
                  <div className="font-mono font-bold text-primary">{(config.base_frequency / 100).toFixed(2)} Hz</div>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground text-xs uppercase tracking-wider">Modulation</span>
                  <div className="font-mono font-bold text-secondary">{(config.mod_frequency / 100).toFixed(2)} Hz</div>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground text-xs uppercase tracking-wider">Voltage</span>
                  <div className="font-mono font-bold text-white">{(config.voltage / 1000).toFixed(1)} kV</div>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground text-xs uppercase tracking-wider">Current</span>
                  <div className="font-mono font-bold text-white">{config.current} mA</div>
                </div>
              </div>
            </CardContent>

            <CardFooter className="flex justify-end gap-2 border-t border-white/5 pt-4">
              <Button variant="ghost" size="sm" onClick={() => deleteConfig(config.id)} className="text-muted-foreground hover:text-destructive">
                <Trash2 className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={() => openEditConfig(config)} className="border-white/10 hover:bg-white/5">
                <Edit2 className="h-4 w-4 mr-2" /> Edit
              </Button>
              <Button size="sm" className="bg-primary/20 text-primary hover:bg-primary/30 border border-primary/50">
                <Play className="h-4 w-4 mr-2" /> Run
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-card border-white/10 sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">{editingConfig?.id === 0 ? 'Create Protocol' : 'Edit Protocol'}</DialogTitle>
          </DialogHeader>
          
          {editingConfig && (
            <form onSubmit={handleSave} className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2 col-span-2">
                  <Label>Protocol Name</Label>
                  <Input 
                    value={editingConfig.name} 
                    onChange={e => setEditingConfig({...editingConfig, name: e.target.value})}
                    className="bg-black/20 border-white/10"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Description</Label>
                  <Input 
                    value={editingConfig.description} 
                    onChange={e => setEditingConfig({...editingConfig, description: e.target.value})}
                    className="bg-black/20 border-white/10"
                  />
                </div>
                
                <div className="space-y-4 col-span-2 p-4 border border-white/5 rounded-lg bg-white/5">
                   <div className="flex items-center justify-between">
                     <Label>Base Frequency (Hz)</Label>
                     <span className="font-mono text-primary">{(editingConfig.base_frequency / 100).toFixed(2)}</span>
                   </div>
                   <Slider 
                     min={100} max={20000} step={10} 
                     value={[editingConfig.base_frequency]} 
                     onValueChange={v => setEditingConfig({...editingConfig, base_frequency: v[0]})}
                     className="py-2"
                   />
                </div>

                <div className="space-y-4 col-span-2 p-4 border border-white/5 rounded-lg bg-white/5">
                   <div className="flex items-center justify-between">
                     <Label>Modulation Frequency (Hz)</Label>
                     <span className="font-mono text-secondary">{(editingConfig.mod_frequency / 100).toFixed(2)}</span>
                   </div>
                   <Slider 
                     min={100} max={10000} step={10} 
                     value={[editingConfig.mod_frequency]} 
                     onValueChange={v => setEditingConfig({...editingConfig, mod_frequency: v[0]})}
                     className="py-2"
                   />
                </div>

                <div className="space-y-2">
                  <Label>Voltage (kV)</Label>
                  <Input 
                    type="number" 
                    value={editingConfig.voltage / 1000} 
                    onChange={e => setEditingConfig({...editingConfig, voltage: Number(e.target.value) * 1000})}
                    className="bg-black/20 border-white/10"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Current (mA)</Label>
                  <Input 
                    type="number" 
                    value={editingConfig.current} 
                    onChange={e => setEditingConfig({...editingConfig, current: Number(e.target.value)})}
                    className="bg-black/20 border-white/10"
                  />
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button type="submit" className="bg-primary text-primary-foreground">Save Changes</Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
