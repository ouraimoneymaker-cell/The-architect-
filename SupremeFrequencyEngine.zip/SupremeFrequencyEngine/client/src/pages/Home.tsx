import React from 'react';
import { Link } from 'wouter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BrainCircuit, Activity, Radio, ArrowRight, Lock } from "lucide-react";
import bgImage from '@assets/generated_images/abstract_dark_quantum_frequency_waves_background.png';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
       {/* Background */}
       <div 
        className="absolute inset-0 z-[-1]"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(10, 12, 24, 0.7), rgba(10, 12, 24, 0.95)), url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Navbar */}
      <header className="w-full px-6 py-6 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
            <BrainCircuit className="w-6 h-6 text-primary" />
          </div>
          <div>
             <h1 className="text-xl font-display font-bold text-white tracking-wider">SFEA</h1>
             <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em]">Supreme Frequency Engine</p>
          </div>
        </div>
        <Link href="/auth">
          <Button variant="outline" className="border-white/10 hover:bg-white/5 text-white">
            <Lock className="mr-2 h-4 w-4" /> Member Access
          </Button>
        </Link>
      </header>

      {/* Hero */}
      <main className="flex-1 container mx-auto px-4 flex flex-col items-center justify-center text-center z-10 py-20">
        <div className="max-w-3xl space-y-8">
          <div className="inline-block px-4 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-sm font-medium tracking-wider mb-4">
            SYSTEM STATUS: ONLINE
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-white tracking-tight leading-tight">
            Architect Your <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-secondary animate-pulse">Internal Resonance</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            The Supreme Frequency Engine Architect (SFEA) unifies Tesla coils, Rife frequencies, and biofeedback into a single coherence interface.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Link href="/auth">
              <Button size="lg" className="h-14 px-8 text-lg bg-primary hover:bg-primary/80 text-primary-foreground font-bold shadow-[0_0_30px_rgba(6,182,212,0.4)] transition-all hover:scale-105">
                Enter The Architect
              </Button>
            </Link>
            <Link href="/about">
              <Button size="lg" variant="outline" className="h-14 px-8 text-lg border-white/10 hover:bg-white/5 text-white">
                Learn The Science
              </Button>
            </Link>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-32 w-full max-w-6xl text-left">
          <Card className="bg-card/40 border-white/10 backdrop-blur-md hover:border-primary/30 transition-colors group">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <BrainCircuit className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle className="text-white">Ritual of Intent</CardTitle>
              <CardDescription>Psychological priming sequence</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Align your subconscious through a structured intention-setting and breathing protocol before every session.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-white/10 backdrop-blur-md hover:border-primary/30 transition-colors group">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Radio className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-white">Frequency Synthesis</CardTitle>
              <CardDescription>Tesla-Rife Unified Field</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Generate complex scalar waves with nested harmonics, tunable from Schumann resonances to Rife carrier waves.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-white/10 backdrop-blur-md hover:border-primary/30 transition-colors group">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Activity className="w-6 h-6 text-accent" />
              </div>
              <CardTitle className="text-white">Biofeedback Loop</CardTitle>
              <CardDescription>Real-time coherence tracking</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                The engine adapts to your Heart Rate Variability (HRV) and Galvanic Skin Response (GSR) in real-time.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
      
      <footer className="w-full py-8 border-t border-white/5 text-center text-xs text-muted-foreground">
         <p>© 2025 Supreme Frequency Engine Architect. Experimental Interface.</p>
         <p className="mt-2 max-w-2xl mx-auto px-4">
           DISCLAIMER: This system is a conceptual prototype. No medical claims are made. 
           Interaction with scalar fields is hypothetical.
         </p>
      </footer>
    </div>
  );
}
