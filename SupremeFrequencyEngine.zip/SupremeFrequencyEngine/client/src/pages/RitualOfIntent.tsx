import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MOCK_FREQUENCIES, MOCK_CHAKRAS } from '@/lib/mock-data';
import { Wind, ArrowRight, CheckCircle2, Zap, Brain } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

const PHASES = {
  INTENTION: 0,
  BREATHING: 1,
  ACTIVATION: 2
};

export default function RitualOfIntent() {
  const [phase, setPhase] = useState(PHASES.INTENTION);
  const [intention, setIntention] = useState("");
  const [selectedConfig, setSelectedConfig] = useState<string>(MOCK_FREQUENCIES[0].id.toString());
  const [breathCount, setBreathCount] = useState(60); // 60 seconds
  const [breathState, setBreathState] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [_, setLocation] = useLocation();

  // Breathing Timer Logic
  useEffect(() => {
    if (phase === PHASES.BREATHING && breathCount > 0) {
      const timer = setInterval(() => {
        setBreathCount(prev => prev - 1);
        
        // 4-4-4 Box Breathing Cycle (12s total)
        const cycle = 12;
        const remainder = breathCount % cycle;
        
        if (remainder > 8) setBreathState("inhale");
        else if (remainder > 4) setBreathState("hold");
        else setBreathState("exhale");
        
      }, 1000);
      return () => clearInterval(timer);
    } else if (phase === PHASES.BREATHING && breathCount === 0) {
      setPhase(PHASES.ACTIVATION);
    }
  }, [phase, breathCount]);

  const handleStartBreathing = () => {
    if (!intention) {
      toast({ title: "Intention Required", description: "Please state your intention before proceeding.", variant: "destructive" });
      return;
    }
    setPhase(PHASES.BREATHING);
  };

  const handleActivate = () => {
    toast({ title: "Coherence Field Activated", description: "Your session has begun." });
    setLocation('/session');
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="text-center mb-12 space-y-4">
        <h1 className="text-4xl font-display font-bold text-white tracking-wider">RITUAL OF INTENT</h1>
        <p className="text-muted-foreground text-lg">Align your bio-field before entering the coherence chamber.</p>
        
        {/* Progress Stepper */}
        <div className="flex justify-center items-center gap-4 mt-8">
          {[
            { id: PHASES.INTENTION, label: "Intention" },
            { id: PHASES.BREATHING, label: "Resonance" },
            { id: PHASES.ACTIVATION, label: "Activation" }
          ].map((step, idx) => (
            <div key={step.id} className="flex items-center gap-2">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border transition-all",
                phase >= step.id 
                  ? "bg-primary text-primary-foreground border-primary shadow-[0_0_10px_theme(colors.primary.DEFAULT)]" 
                  : "bg-transparent text-muted-foreground border-white/10"
              )}>
                {idx + 1}
              </div>
              <span className={cn(
                "text-sm uppercase tracking-wider",
                phase >= step.id ? "text-primary" : "text-muted-foreground"
              )}>{step.label}</span>
              {idx < 2 && <div className="w-12 h-[1px] bg-white/10 mx-2" />}
            </div>
          ))}
        </div>
      </div>

      <div className="relative min-h-[500px]">
        <AnimatePresence mode="wait">
          {/* PHASE 1: INTENTION */}
          {phase === PHASES.INTENTION && (
            <motion.div
              key="intention"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-8 space-y-8">
                <div className="space-y-4">
                  <Label className="text-lg text-white">1. Select Frequency Protocol</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {MOCK_FREQUENCIES.map(f => (
                       <div 
                         key={f.id}
                         onClick={() => setSelectedConfig(f.id.toString())}
                         className={cn(
                           "p-4 rounded-lg border cursor-pointer transition-all hover:bg-white/5",
                           selectedConfig === f.id.toString()
                             ? "border-primary bg-primary/5 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                             : "border-white/10"
                         )}
                       >
                         <div className="font-bold text-white mb-1">{f.name}</div>
                         <div className="text-xs text-muted-foreground">{f.description}</div>
                         <div className="mt-2 text-xs font-mono text-primary">{(f.base_frequency / 100).toFixed(2)} Hz</div>
                       </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <Label className="text-lg text-white">2. State Your Intention</Label>
                  <Input 
                    value={intention}
                    onChange={(e) => setIntention(e.target.value)}
                    placeholder="I seek clarity and inner peace..."
                    className="h-16 text-lg bg-black/20 border-white/10 focus-visible:ring-primary"
                  />
                  <p className="text-sm text-muted-foreground">
                    This statement will be encoded into the scalar field modulation.
                  </p>
                </div>

                <div className="flex justify-end pt-4">
                  <Button 
                    size="lg" 
                    onClick={handleStartBreathing}
                    className="bg-primary hover:bg-primary/80 text-primary-foreground font-bold px-8"
                  >
                    Begin Resonance <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}

          {/* PHASE 2: BREATHING */}
          {phase === PHASES.BREATHING && (
            <motion.div
              key="breathing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex flex-col items-center justify-center py-12 space-y-12"
            >
              <div className="relative">
                {/* Breathing Circle Animation */}
                <motion.div 
                  animate={{
                    scale: breathState === "inhale" ? 1.5 : breathState === "hold" ? 1.5 : 1,
                    opacity: breathState === "hold" ? 0.8 : 0.5,
                  }}
                  transition={{ duration: 4, ease: "easeInOut" }}
                  className="w-64 h-64 rounded-full bg-primary/20 blur-2xl absolute inset-0 m-auto"
                />
                <motion.div 
                  animate={{
                    scale: breathState === "inhale" ? 1.2 : breathState === "hold" ? 1.2 : 1,
                    borderColor: breathState === "hold" ? "rgba(255,255,255,0.5)" : "rgba(6,182,212,0.5)"
                  }}
                  transition={{ duration: 4, ease: "easeInOut" }}
                  className="w-64 h-64 rounded-full border-2 border-primary flex items-center justify-center relative z-10 backdrop-blur-sm bg-black/20"
                >
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white uppercase tracking-widest mb-2">
                      {breathState}
                    </div>
                    <div className="text-4xl font-mono font-bold text-primary">
                      {breathCount}s
                    </div>
                  </div>
                </motion.div>
              </div>

              <div className="text-center space-y-2 max-w-md">
                <h3 className="text-xl font-bold text-white">Synchronize Your Field</h3>
                <p className="text-muted-foreground">
                  Inhale for 4s • Hold for 4s • Exhale for 4s
                </p>
              </div>

              <Button variant="ghost" onClick={() => setPhase(PHASES.ACTIVATION)} className="text-muted-foreground hover:text-white">
                Skip Breathing Exercise
              </Button>
            </motion.div>
          )}

          {/* PHASE 3: ACTIVATION */}
          {phase === PHASES.ACTIVATION && (
            <motion.div
              key="activation"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center space-y-8"
            >
              <Card className="w-full max-w-lg bg-card/50 border-white/10 backdrop-blur-sm p-8 text-center space-y-6 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
                
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto border border-primary/20 shadow-[0_0_30px_rgba(6,182,212,0.3)]">
                  <Zap className="w-10 h-10 text-primary" />
                </div>

                <div className="space-y-2">
                  <h2 className="text-2xl font-display font-bold text-white">System Ready</h2>
                  <p className="text-muted-foreground">Coherence field parameters locked.</p>
                </div>

                <div className="text-left bg-black/40 p-4 rounded-lg border border-white/5 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Protocol:</span>
                    <span className="text-white font-medium">{MOCK_FREQUENCIES.find(f => f.id.toString() === selectedConfig)?.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Intention:</span>
                    <span className="text-white font-medium italic">"{intention}"</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Bio-Feedback:</span>
                    <span className="text-emerald-400 font-medium flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Active</span>
                  </div>
                </div>

                <Button 
                  size="lg" 
                  onClick={handleActivate}
                  className="w-full h-14 text-lg bg-primary hover:bg-primary/80 text-primary-foreground font-bold shadow-[0_0_30px_rgba(6,182,212,0.4)] animate-pulse"
                >
                  INITIATE SESSION
                </Button>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
