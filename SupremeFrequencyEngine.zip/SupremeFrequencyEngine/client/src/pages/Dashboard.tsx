import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Activity, Zap, Clock, Brain, ArrowRight, TrendingUp } from "lucide-react";
import { MOCK_USER, MOCK_SESSIONS } from "@/lib/mock-data";
import { Link } from 'wouter';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Mon', hrv: 40 },
  { name: 'Tue', hrv: 30 },
  { name: 'Wed', hrv: 55 },
  { name: 'Thu', hrv: 45 },
  { name: 'Fri', hrv: 70 },
  { name: 'Sat', hrv: 65 },
  { name: 'Sun', hrv: 85 },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-white mb-1">
            Welcome back, <span className="text-primary">{MOCK_USER.name}</span>
          </h1>
          <p className="text-muted-foreground font-sans text-lg">
            System Coherence: <span className="text-secondary font-bold">98.4%</span> | Status: <span className="text-emerald-400">Nominal</span>
          </p>
        </div>
        <Link href="/session">
          <Button className="bg-primary hover:bg-primary/80 text-primary-foreground font-bold px-8 shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all hover:shadow-[0_0_30px_rgba(6,182,212,0.5)]">
            <Zap className="mr-2 h-4 w-4" /> Initialize Session
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card/50 border-white/10 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Coherence</CardTitle>
            <Activity className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-white">87%</div>
            <p className="text-xs text-emerald-400 mt-1 flex items-center">
              <TrendingUp className="h-3 w-3 mr-1" /> +2.5% from last week
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card/50 border-white/10 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Duration</CardTitle>
            <Clock className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-white">42h 15m</div>
            <p className="text-xs text-muted-foreground mt-1">Across 24 sessions</p>
          </CardContent>
        </Card>
        <Card className="bg-card/50 border-white/10 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Resonance Peak</CardTitle>
            <Zap className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-white">7.83 Hz</div>
            <p className="text-xs text-muted-foreground mt-1">Optimal alignment</p>
          </CardContent>
        </Card>
        <Card className="bg-card/50 border-white/10 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Mental State</CardTitle>
            <Brain className="h-4 w-4 text-rose-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-white">Flow</div>
            <p className="text-xs text-muted-foreground mt-1">Detected 2h ago</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Chart & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="col-span-2 bg-card/50 border-white/10 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Coherence Trends</CardTitle>
            <CardDescription>7-day Heart Rate Variability analysis</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorHrv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="name" 
                  stroke="#888888" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#888888" 
                  fontSize={12} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(value) => `${value}`} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))' }}
                  itemStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="hrv" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorHrv)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card/50 border-white/10 backdrop-blur-sm flex flex-col">
          <CardHeader>
            <CardTitle>Recent Sessions</CardTitle>
            <CardDescription>History log</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto pr-2">
            <div className="space-y-4">
              {MOCK_SESSIONS.map((session) => (
                <div key={session.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-white">{session.intention}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{new Date(session.created_at).toLocaleDateString()}</span>
                      <span>•</span>
                      <span>{Math.floor(session.duration_seconds / 60)} min</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-secondary">{session.coherence_score}%</div>
                    <p className="text-[10px] text-muted-foreground">Score</p>
                  </div>
                </div>
              ))}
              <Button variant="ghost" className="w-full text-xs text-muted-foreground hover:text-white mt-2">
                View All History <ArrowRight className="ml-1 h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
