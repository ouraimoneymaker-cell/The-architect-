import React from 'react';
import { MOCK_CHAKRAS } from '@/lib/mock-data';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export default function ChakraReference() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-white">Chakra Resonance Map</h1>
        <p className="text-muted-foreground">Solfeggio frequencies aligned with bio-energetic centers.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {MOCK_CHAKRAS.map((chakra) => (
          <Card 
            key={chakra.id} 
            className="bg-card/50 border-white/10 backdrop-blur-sm overflow-hidden group hover:scale-[1.02] transition-transform duration-300"
            style={{
              boxShadow: `0 0 0 1px ${chakra.color}20` // subtle colored border
            }}
          >
            <div 
              className="h-2 w-full"
              style={{ backgroundColor: chakra.color, boxShadow: `0 0 10px ${chakra.color}` }}
            />
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg font-bold text-white">{chakra.name}</CardTitle>
                <span 
                  className="font-mono text-lg font-bold"
                  style={{ color: chakra.color }}
                >
                  {chakra.frequency_range}
                </span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground h-10">{chakra.description}</p>
              
              <div className="pt-4 border-t border-white/5">
                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-muted-foreground">
                  <div>EXACT FREQ</div>
                  <div className="text-white text-right">{(chakra.frequency_hz / 100).toFixed(2)} Hz</div>
                </div>
              </div>
            </CardContent>
            
            {/* Hover Glow Effect */}
            <div 
              className="absolute inset-0 opacity-0 group-hover:opacity-10 pointer-events-none transition-opacity duration-500"
              style={{ background: `radial-gradient(circle at center, ${chakra.color}, transparent 70%)` }}
            />
          </Card>
        ))}
      </div>
    </div>
  );
}
