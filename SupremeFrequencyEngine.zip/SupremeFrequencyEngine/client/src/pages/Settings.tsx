import React from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { User, Shield, Bell, Sliders, Database } from "lucide-react";

export default function Settings() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-white">System Settings</h1>
        <p className="text-muted-foreground">Configure engine parameters and user preferences.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Navigation (Visual only) */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-2">
             <Button variant="ghost" className="w-full justify-start text-primary bg-primary/10">
               <User className="mr-2 h-4 w-4" /> Profile
             </Button>
             <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-white">
               <Sliders className="mr-2 h-4 w-4" /> Engine Config
             </Button>
             <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-white">
               <Shield className="mr-2 h-4 w-4" /> Safety Limits
             </Button>
             <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-white">
               <Bell className="mr-2 h-4 w-4" /> Notifications
             </Button>
             <Button variant="ghost" className="w-full justify-start text-muted-foreground hover:text-white">
               <Database className="mr-2 h-4 w-4" /> Data Management
             </Button>
          </Card>
        </div>

        {/* Right Column: Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-6 space-y-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <User className="h-5 w-5 text-primary" /> User Profile
            </h2>
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Username</Label>
                  <Input defaultValue="neo_architect" className="bg-black/20 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input defaultValue="neo@sfea.io" className="bg-black/20 border-white/10" />
                </div>
              </div>
              <div className="space-y-2">
                 <Label>Bio-Signature ID</Label>
                 <Input defaultValue="8f92-x992-kl22-99s2" disabled className="bg-black/40 border-white/5 text-muted-foreground" />
              </div>
            </div>
            <div className="flex justify-end">
              <Button className="bg-primary text-primary-foreground">Save Profile</Button>
            </div>
          </Card>

          <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-6 space-y-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Shield className="h-5 w-5 text-secondary" /> Safety Limits
            </h2>
            <div className="space-y-4">
               <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-white/5">
                 <div className="space-y-0.5">
                   <Label className="text-base text-white">Max Voltage Protection</Label>
                   <p className="text-sm text-muted-foreground">Automatically cut off if voltage exceeds 60kV</p>
                 </div>
                 <Switch defaultChecked />
               </div>
               <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-white/5">
                 <div className="space-y-0.5">
                   <Label className="text-base text-white">Bio-Feedback Loop</Label>
                   <p className="text-sm text-muted-foreground">Adjust frequency based on HRV response</p>
                 </div>
                 <Switch defaultChecked />
               </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
