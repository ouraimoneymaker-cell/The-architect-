import React from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BrainCircuit } from 'lucide-react';
import bgImage from '@assets/generated_images/abstract_dark_quantum_frequency_waves_background.png';

export default function Auth() {
  const [_, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation('/dashboard');
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden">
      {/* Background */}
      <div 
        className="absolute inset-0 z-[-1]"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(10, 12, 24, 0.8), rgba(10, 12, 24, 0.95)), url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      <Card className="w-full max-w-md bg-black/40 border-white/10 backdrop-blur-xl shadow-2xl">
        <CardHeader className="space-y-1 flex flex-col items-center text-center pb-8">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4 border border-primary/20 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
            <BrainCircuit className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl font-display font-bold text-white tracking-wider">SFEA ACCESS</CardTitle>
          <CardDescription>Supreme Frequency Engine Architect</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Identity Key</Label>
              <Input 
                placeholder="username" 
                className="bg-white/5 border-white/10 text-white placeholder:text-white/20 focus-visible:ring-primary"
                defaultValue="neo_architect"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Access Code</Label>
              <Input 
                type="password" 
                placeholder="••••••••" 
                className="bg-white/5 border-white/10 text-white placeholder:text-white/20 focus-visible:ring-primary"
                defaultValue="password"
              />
            </div>
            <Button type="submit" className="w-full bg-primary hover:bg-primary/80 text-primary-foreground font-bold mt-4 h-12 shadow-[0_0_20px_rgba(6,182,212,0.2)] transition-all hover:shadow-[0_0_30px_rgba(6,182,212,0.4)]">
              INITIATE CONNECTION
            </Button>
          </form>
        </CardContent>
        <CardFooter className="justify-center border-t border-white/5 pt-6">
          <p className="text-xs text-muted-foreground text-center">
            Authorized Personnel Only. <br/>
            Unsafe frequency modulation is prohibited.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
