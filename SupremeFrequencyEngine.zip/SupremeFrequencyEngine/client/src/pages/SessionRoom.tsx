import React, { useState, useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WaveVisualizer } from '@/components/ui/wave-visualizer';
import { Play, Pause, Square, Heart, Zap, Timer, Info } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { MOCK_FREQUENCIES } from '@/lib/mock-data';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function SessionRoom() {
  const [isActive, setIsActive] = useState(false);
  const [duration, setDuration] = useState(0);
  const [selectedConfigId, setSelectedConfigId] = useState(MOCK_FREQUENCIES[0].id.toString());
  const [intention, setIntention] = useState("");
  
  // Simulated live data
  const [dataPoints, setDataPoints] = useState<{time: number, hrv: number, gsr: number}[]>([]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive) {
      interval = setInterval(() => {
        setDuration(d => d + 1);
        
        // Simulate data
        setDataPoints(prev => {
          const newPoint = {
            time: prev.length,
            hrv: 50 + Math.sin(Date.now() / 1000) * 10 + Math.random() * 5,
            gsr: 30 + Math.cos(Date.now() / 2000) * 5 + Math.random() * 2
          };
          const newData = [...prev, newPoint];
          if (newData.length > 50) newData.shift();
          return newData;
        });

      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  const selectedConfig = MOCK_FREQUENCIES.find(c => c.id.toString() === selectedConfigId);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-[calc(100vh-100px)] grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Left Column: Controls */}
      <div className="lg:col-span-4 space-y-6 flex flex-col">
        <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-6 space-y-6 flex-1">
          <div>
            <h2 className="text-xl font-display font-bold text-white mb-4">Session Configuration</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Select Protocol</label>
                <Select value={selectedConfigId} onValueChange={setSelectedConfigId} disabled={isActive}>
                  <SelectTrigger className="bg-black/20 border-white/10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {MOCK_FREQUENCIES.map(f => (
                      <SelectItem key={f.id} value={f.id.toString()}>{f.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Intention</label>
                <Input 
                  placeholder="Enter your intention for this session..."
                  value={intention}
                  onChange={e => setIntention(e.target.value)}
                  className="bg-black/20 border-white/10 h-24 items-start pt-2"
                  disabled={isActive}
                />
              </div>
            </div>
          </div>

          <div className="py-8 flex flex-col items-center justify-center space-y-4">
            <div className="text-6xl font-mono font-bold text-white tracking-widest tabular-nums neon-text">
              {formatTime(duration)}
            </div>
            <div className="flex gap-4">
              {!isActive ? (
                <Button 
                  size="lg" 
                  onClick={() => setIsActive(true)} 
                  className="h-16 w-16 rounded-full bg-primary hover:bg-primary/80 shadow-[0_0_30px_rgba(6,182,212,0.4)] transition-all hover:scale-105"
                >
                  <Play className="h-8 w-8 text-primary-foreground ml-1" />
                </Button>
              ) : (
                <Button 
                  size="lg" 
                  onClick={() => setIsActive(false)} 
                  className="h-16 w-16 rounded-full bg-yellow-500 hover:bg-yellow-400 text-black"
                >
                  <Pause className="h-8 w-8" />
                </Button>
              )}
              <Button 
                size="lg" 
                variant="outline" 
                onClick={() => { setIsActive(false); setDuration(0); setDataPoints([]); }}
                className="h-16 w-16 rounded-full border-white/10 hover:bg-destructive/20 hover:border-destructive/50 hover:text-destructive"
              >
                <Square className="h-6 w-6" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
             <div className="text-center p-3 bg-white/5 rounded-lg">
                <div className="text-xs text-muted-foreground uppercase">Base Freq</div>
                <div className="text-xl font-mono font-bold text-primary">{(selectedConfig?.base_frequency || 0) / 100} Hz</div>
             </div>
             <div className="text-center p-3 bg-white/5 rounded-lg">
                <div className="text-xs text-muted-foreground uppercase">Modulation</div>
                <div className="text-xl font-mono font-bold text-secondary">{(selectedConfig?.mod_frequency || 0) / 100} Hz</div>
             </div>
          </div>
        </Card>
      </div>

      {/* Right Column: Visuals & Data */}
      <div className="lg:col-span-8 flex flex-col gap-6">
        {/* Main Visualizer */}
        <div className="flex-1 min-h-[400px] relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-black/50">
          <div className="absolute inset-0 z-0">
            <WaveVisualizer 
              isActive={isActive} 
              frequency={selectedConfig?.base_frequency || 500} 
              amplitude={50}
              color="hsl(var(--primary))"
            />
          </div>
          <div className="absolute top-4 right-4 z-10 flex flex-col items-end gap-2">
            <div className="bg-black/60 backdrop-blur px-3 py-1 rounded border border-white/10 text-xs font-mono text-emerald-400">
              FIELD STRENGTH: {(isActive ? 98 : 0).toFixed(1)}%
            </div>
            <div className="bg-black/60 backdrop-blur px-3 py-1 rounded border border-white/10 text-xs font-mono text-primary">
              RESONANCE: {(isActive ? 'LOCKED' : 'STANDBY')}
            </div>
          </div>
        </div>

        {/* Live Charts */}
        <div className="h-[200px] grid grid-cols-2 gap-6">
          <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-4 flex flex-col">
            <div className="flex items-center justify-between mb-2">
               <div className="flex items-center gap-2 text-sm font-bold text-rose-400">
                 <Heart className="w-4 h-4" /> HRV (ms)
               </div>
               <span className="font-mono text-xs text-muted-foreground">Live</span>
            </div>
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dataPoints}>
                  <Area type="monotone" dataKey="hrv" stroke="#fb7185" fill="#fb7185" fillOpacity={0.1} strokeWidth={2} isAnimationActive={false} />
                  <YAxis hide domain={['auto', 'auto']} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="bg-card/50 border-white/10 backdrop-blur-sm p-4 flex flex-col">
            <div className="flex items-center justify-between mb-2">
               <div className="flex items-center gap-2 text-sm font-bold text-cyan-400">
                 <Zap className="w-4 h-4" /> GSR (μS)
               </div>
               <span className="font-mono text-xs text-muted-foreground">Live</span>
            </div>
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dataPoints}>
                  <Area type="monotone" dataKey="gsr" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.1} strokeWidth={2} isAnimationActive={false} />
                  <YAxis hide domain={['auto', 'auto']} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </div>

    </div>
  );
}
