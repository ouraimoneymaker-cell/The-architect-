import React from 'react';
import { Link, useLocation } from 'wouter';
import { 
  LayoutDashboard, 
  Activity, 
  Zap, 
  Radio, 
  Settings, 
  LogOut, 
  BrainCircuit,
  Menu
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import bgImage from '@assets/generated_images/abstract_dark_quantum_frequency_waves_background.png';

const NAV_ITEMS = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
  { label: 'Ritual of Intent', icon: BrainCircuit, path: '/ritual' },
  { label: 'Frequency Lab', icon: Radio, path: '/lab' },
  { label: 'Session Room', icon: Zap, path: '/session' },
  { label: 'Chakra Reference', icon: Activity, path: '/chakras' },
  { label: 'System Settings', icon: Settings, path: '/settings' },
];

const SidebarContent = ({ pathname }: { pathname: string }) => (
  <div className="flex flex-col h-full bg-card/80 backdrop-blur-md border-r border-white/10">
    <div className="p-6 flex items-center gap-3 border-b border-white/10">
      <BrainCircuit className="w-8 h-8 text-primary animate-pulse" />
      <div>
        <h1 className="text-xl font-display font-bold tracking-wider text-foreground">SFEA</h1>
        <p className="text-[10px] text-muted-foreground tracking-widest uppercase">Supreme Engine</p>
      </div>
    </div>

    <nav className="flex-1 p-4 space-y-2">
      {NAV_ITEMS.map((item) => {
        const isActive = pathname === item.path;
        return (
          <Link key={item.path} href={item.path}>
            <div 
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-md transition-all duration-200 cursor-pointer group",
                isActive 
                  ? "bg-primary/10 text-primary border-l-2 border-primary shadow-[0_0_15px_rgba(0,255,255,0.1)]" 
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              )}
            >
              <item.icon className={cn("w-5 h-5 transition-colors", isActive ? "text-primary" : "group-hover:text-primary")} />
              <span className="font-sans font-medium tracking-wide">{item.label}</span>
            </div>
          </Link>
        );
      })}
    </nav>

    <div className="p-4 border-t border-white/10">
      <div className="flex items-center gap-3 px-4 py-3 text-muted-foreground hover:text-destructive cursor-pointer transition-colors">
        <LogOut className="w-5 h-5" />
        <span className="font-sans font-medium">Disconnect</span>
      </div>
    </div>
  </div>
);

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex w-full relative overflow-hidden">
      {/* Background Image Layer */}
      <div 
        className="fixed inset-0 z-[-1]"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(10, 12, 24, 0.92), rgba(10, 12, 24, 0.96)), url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-72 h-screen sticky top-0 z-50">
        <SidebarContent pathname={location} />
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-card/90 backdrop-blur border-b border-white/10 z-50 px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-6 h-6 text-primary" />
          <span className="font-display font-bold">SFEA</span>
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72 bg-transparent border-none">
             <SidebarContent pathname={location} />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 min-h-screen pt-16 md:pt-0 overflow-x-hidden">
        <div className="container mx-auto p-4 md:p-8 max-w-7xl animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}
