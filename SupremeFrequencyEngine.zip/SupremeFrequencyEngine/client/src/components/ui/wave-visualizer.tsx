import React, { useEffect, useRef } from 'react';

interface WaveVisualizerProps {
  isActive: boolean;
  frequency: number; // normalized 0-100 for visual speed
  amplitude: number; // normalized 0-100 for visual height
  color: string;
}

export const WaveVisualizer: React.FC<WaveVisualizerProps> = ({ isActive, frequency, amplitude, color }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.parentElement?.clientWidth || 300;
      canvas.height = canvas.parentElement?.clientHeight || 150;
    };
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    let offset = 0;

    const draw = () => {
      if (!ctx || !canvas) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Base line
      ctx.beginPath();
      ctx.moveTo(0, canvas.height / 2);
      
      const freqVal = isActive ? frequency * 0.02 : 0.005;
      const ampVal = isActive ? amplitude * 0.5 : 5;
      
      for (let x = 0; x < canvas.width; x++) {
        // Combine multiple sine waves for "interference" look
        const y = canvas.height / 2 + 
          Math.sin(x * freqVal + offset) * ampVal +
          Math.sin(x * (freqVal * 0.5) + offset * 1.5) * (ampVal * 0.5);
        
        ctx.lineTo(x, y);
      }
      
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.shadowBlur = 10;
      ctx.shadowColor = color;
      ctx.stroke();
      
      offset += isActive ? 0.1 : 0.02;
      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationRef.current);
    };
  }, [isActive, frequency, amplitude, color]);

  return (
    <div className="w-full h-full min-h-[200px] bg-black/40 rounded-lg border border-white/5 overflow-hidden relative">
       <div className="absolute inset-0 grid grid-cols-12 grid-rows-6 pointer-events-none opacity-20">
         {Array.from({ length: 72 }).map((_, i) => (
           <div key={i} className="border border-primary/20"></div>
         ))}
       </div>
       <canvas ref={canvasRef} className="w-full h-full relative z-10" />
    </div>
  );
};
