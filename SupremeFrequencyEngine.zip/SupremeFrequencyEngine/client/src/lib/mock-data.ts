import { z } from "zod";

export interface User {
  id: number;
  username: string;
  email: string;
  name: string;
  role: "user" | "admin";
}

export interface FrequencyConfig {
  id: number;
  name: string;
  description: string;
  base_frequency: number; // Hz * 100
  mod_frequency: number;  // Hz * 100
  carrier_frequency: number; // Hz * 100
  voltage: number; // Volts
  current: number; // mA
  is_active: boolean;
}

export interface Session {
  id: number;
  config_id: number;
  intention: string;
  duration_seconds: number;
  start_hrv: number;
  coherence_score: number;
  status: "active" | "completed" | "paused";
  created_at: string;
}

export interface ChakraFrequency {
  id: number;
  name: string;
  frequency_hz: number;
  frequency_range: string;
  color: string;
  description: string;
}

export const MOCK_USER: User = {
  id: 1,
  username: "neo_architect",
  email: "neo@sfea.io",
  name: "Neo Architect",
  role: "admin"
};

export const MOCK_FREQUENCIES: FrequencyConfig[] = [
  {
    id: 1,
    name: "Schumann Resonance",
    description: "Earth's atmospheric base frequency for grounding.",
    base_frequency: 783,
    mod_frequency: 4000,
    carrier_frequency: 2712000,
    voltage: 50000,
    current: 10,
    is_active: true
  },
  {
    id: 2,
    name: "Gamma Focus",
    description: "High frequency for peak cognitive performance.",
    base_frequency: 4000,
    mod_frequency: 4000,
    carrier_frequency: 2712000,
    voltage: 55000,
    current: 12,
    is_active: false
  },
  {
    id: 3,
    name: "Delta Deep Sleep",
    description: "Low frequency for restorative sleep and healing.",
    base_frequency: 250,
    mod_frequency: 3500,
    carrier_frequency: 2712000,
    voltage: 45000,
    current: 8,
    is_active: false
  }
];

export const MOCK_CHAKRAS: ChakraFrequency[] = [
  { id: 1, name: "Root", frequency_hz: 39600, frequency_range: "396 Hz", color: "#FF0000", description: "Liberating Guilt and Fear" },
  { id: 2, name: "Sacral", frequency_hz: 41700, frequency_range: "417 Hz", color: "#FF7F00", description: "Undoing Situations and Facilitating Change" },
  { id: 3, name: "Solar Plexus", frequency_hz: 52800, frequency_range: "528 Hz", color: "#FFFF00", description: "Transformation and Miracles (DNA Repair)" },
  { id: 4, name: "Heart", frequency_hz: 63900, frequency_range: "639 Hz", color: "#00FF00", description: "Connecting/Relationships" },
  { id: 5, name: "Throat", frequency_hz: 74100, frequency_range: "741 Hz", color: "#0000FF", description: "Expression/Solutions" },
  { id: 6, name: "Third Eye", frequency_hz: 85200, frequency_range: "852 Hz", color: "#4B0082", description: "Returning to Spiritual Order" },
  { id: 7, name: "Crown", frequency_hz: 96300, frequency_range: "963 Hz", color: "#9400D3", description: "Awakening Perfect State" },
];

export const MOCK_SESSIONS: Session[] = [
  {
    id: 101,
    config_id: 1,
    intention: "Morning Grounding",
    duration_seconds: 1200,
    start_hrv: 45,
    coherence_score: 82,
    status: "completed",
    created_at: "2025-12-03T08:30:00Z"
  },
  {
    id: 102,
    config_id: 2,
    intention: "Deep Work Sprint",
    duration_seconds: 3600,
    start_hrv: 55,
    coherence_score: 91,
    status: "completed",
    created_at: "2025-12-03T14:00:00Z"
  }
];
