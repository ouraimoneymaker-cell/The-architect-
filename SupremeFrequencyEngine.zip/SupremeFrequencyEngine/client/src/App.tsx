import React from 'react';
import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import Layout from '@/components/layout/Layout';
import Home from '@/pages/Home';
import Dashboard from '@/pages/Dashboard';
import FrequencyLab from '@/pages/FrequencyLab';
import SessionRoom from '@/pages/SessionRoom';
import RitualOfIntent from '@/pages/RitualOfIntent';
import ChakraReference from '@/pages/ChakraReference';
import Auth from '@/pages/Auth';
import Settings from '@/pages/Settings';
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/auth" component={Auth} />
      
      {/* Protected Routes */}
      <Route path="/dashboard">
        <Layout><Dashboard /></Layout>
      </Route>
      <Route path="/lab">
        <Layout><FrequencyLab /></Layout>
      </Route>
      <Route path="/ritual">
         <Layout><RitualOfIntent /></Layout>
      </Route>
      <Route path="/session">
        <Layout><SessionRoom /></Layout>
      </Route>
      <Route path="/chakras">
        <Layout><ChakraReference /></Layout>
      </Route>
      <Route path="/settings">
         <Layout><Settings /></Layout>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
