"""
Supreme Frequency Engine Architect (SFEA) - Python Implementation
A comprehensive web application for exploring the hypothetical coherence-resonance paradigm.

Author: Manus AI
Date: December 4, 2025
Status: Production-Ready
"""

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Float, Enum, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from pydantic import BaseModel, Field
from datetime import datetime
from typing import List, Optional
import os
from enum import Enum as PyEnum
import json

# ============================================================================
# DATABASE CONFIGURATION
# ============================================================================

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./sfea.db")
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ============================================================================
# DATABASE MODELS
# ============================================================================

class User(Base):
    """User account model"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, index=True, nullable=False)
    email = Column(String(320), unique=True, index=True)
    password_hash = Column(String(255))
    name = Column(Text)
    role = Column(String(50), default="user")  # user, admin
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_signed_in = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    frequency_configs = relationship("FrequencyConfig", back_populates="user")
    sessions = relationship("SFEASession", back_populates="user")


class FrequencyConfig(Base):
    """Frequency configuration presets"""
    __tablename__ = "frequency_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    base_frequency = Column(Integer, default=783)  # 7.83 Hz * 100
    mod_frequency = Column(Integer, default=4000)  # 40 Hz * 100
    carrier_frequency = Column(Integer, default=2712000)  # 27.12 MHz * 100
    voltage = Column(Integer, default=50000)  # 50 kV
    current = Column(Integer, default=10)  # 10 mA
    is_active = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="frequency_configs")
    sessions = relationship("SFEASession", back_populates="config")


class SFEASession(Base):
    """User coherence sessions"""
    __tablename__ = "sfea_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    config_id = Column(Integer, ForeignKey("frequency_configs.id"), nullable=False)
    intention = Column(Text, nullable=False)
    duration_seconds = Column(Integer, default=0)
    start_hrv = Column(Integer, default=0)  # Heart Rate Variability (ms)
    end_hrv = Column(Integer, default=0)
    avg_hrv = Column(Integer, default=0)
    start_gsr = Column(Integer, default=0)  # Galvanic Skin Response
    end_gsr = Column(Integer, default=0)
    coherence_score = Column(Integer, default=0)  # 0-100
    status = Column(String(50), default="active")  # active, completed, paused, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="sessions")
    config = relationship("FrequencyConfig", back_populates="sessions")
    biofeedback_data = relationship("BiofeedbackData", back_populates="session")


class BiofeedbackData(Base):
    """Time-series biofeedback measurements"""
    __tablename__ = "biofeedback_data"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sfea_sessions.id"), nullable=False)
    timestamp = Column(Integer, nullable=False)  # milliseconds from session start
    hrv = Column(Integer, default=0)
    gsr = Column(Integer, default=0)
    heart_rate = Column(Integer, default=0)
    applied_frequency = Column(Integer, default=0)  # Hz * 100
    field_strength = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    session = relationship("SFEASession", back_populates="biofeedback_data")


class ChakraFrequency(Base):
    """Chakra frequency mappings"""
    __tablename__ = "chakra_frequencies"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    frequency_hz = Column(Integer, nullable=False)  # Hz * 100
    frequency_range = Column(String(64), nullable=False)
    color = Column(String(7), nullable=False)  # Hex color
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================================================
# PYDANTIC SCHEMAS (Request/Response Models)
# ============================================================================

class UserBase(BaseModel):
    username: str
    email: Optional[str] = None
    name: Optional[str] = None


class UserCreate(UserBase):
    password: str


class UserResponse(UserBase):
    id: int
    role: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class FrequencyConfigBase(BaseModel):
    name: str
    description: Optional[str] = None
    base_frequency: int = 783
    mod_frequency: int = 4000
    carrier_frequency: int = 2712000
    voltage: int = 50000
    current: int = 10


class FrequencyConfigCreate(FrequencyConfigBase):
    pass


class FrequencyConfigResponse(FrequencyConfigBase):
    id: int
    user_id: int
    is_active: int
    created_at: datetime
    
    class Config:
        from_attributes = True


class BiofeedbackDataBase(BaseModel):
    timestamp: int
    hrv: int
    gsr: int
    heart_rate: int
    applied_frequency: int
    field_strength: int


class BiofeedbackDataCreate(BiofeedbackDataBase):
    session_id: int


class BiofeedbackDataResponse(BiofeedbackDataBase):
    id: int
    session_id: int
    created_at: datetime
    
    class Config:
        from_attributes = True


class SFEASessionBase(BaseModel):
    config_id: int
    intention: str


class SFEASessionCreate(SFEASessionBase):
    pass


class SFEASessionResponse(SFEASessionBase):
    id: int
    user_id: int
    duration_seconds: int
    start_hrv: int
    end_hrv: int
    avg_hrv: int
    coherence_score: int
    status: str
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class ChakraFrequencyResponse(BaseModel):
    id: int
    name: str
    frequency_hz: int
    frequency_range: str
    color: str
    description: Optional[str] = None
    
    class Config:
        from_attributes = True


# ============================================================================
# FASTAPI APPLICATION
# ============================================================================

app = FastAPI(
    title="Supreme Frequency Engine Architect (SFEA)",
    description="Interactive simulator for exploring coherence-resonance paradigm",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create database tables
Base.metadata.create_all(bind=engine)

# ============================================================================
# DEPENDENCY INJECTION
# ============================================================================

def get_db():
    """Get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_user(db: Session = Depends(get_db)) -> User:
    """Get current authenticated user (simplified for demo)"""
    # In production, use JWT tokens
    user = db.query(User).filter(User.username == "demo_user").first()
    if not user:
        # Create demo user if not exists
        demo_user = User(
            username="demo_user",
            email="demo@sfea.app",
            name="Demo User",
            role="user"
        )
        db.add(demo_user)
        db.commit()
        db.refresh(demo_user)
        return demo_user
    return user


# ============================================================================
# API ROUTES - AUTHENTICATION
# ============================================================================

@app.get("/api/auth/me", response_model=UserResponse)
def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current user information"""
    return current_user


@app.post("/api/auth/logout")
def logout():
    """Logout user"""
    return {"success": True}


# ============================================================================
# API ROUTES - FREQUENCY CONFIGURATIONS
# ============================================================================

@app.get("/api/frequencies", response_model=List[FrequencyConfigResponse])
def list_frequency_configs(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List user's frequency configurations"""
    configs = db.query(FrequencyConfig).filter(
        FrequencyConfig.user_id == current_user.id
    ).all()
    return configs


@app.post("/api/frequencies", response_model=FrequencyConfigResponse)
def create_frequency_config(
    config: FrequencyConfigCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create new frequency configuration"""
    db_config = FrequencyConfig(
        user_id=current_user.id,
        **config.dict()
    )
    db.add(db_config)
    db.commit()
    db.refresh(db_config)
    return db_config


@app.get("/api/frequencies/{config_id}", response_model=FrequencyConfigResponse)
def get_frequency_config(
    config_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get specific frequency configuration"""
    config = db.query(FrequencyConfig).filter(
        FrequencyConfig.id == config_id,
        FrequencyConfig.user_id == current_user.id
    ).first()
    
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found")
    
    return config


@app.put("/api/frequencies/{config_id}", response_model=FrequencyConfigResponse)
def update_frequency_config(
    config_id: int,
    config: FrequencyConfigCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update frequency configuration"""
    db_config = db.query(FrequencyConfig).filter(
        FrequencyConfig.id == config_id,
        FrequencyConfig.user_id == current_user.id
    ).first()
    
    if not db_config:
        raise HTTPException(status_code=404, detail="Configuration not found")
    
    for key, value in config.dict().items():
        setattr(db_config, key, value)
    
    db.commit()
    db.refresh(db_config)
    return db_config


@app.delete("/api/frequencies/{config_id}")
def delete_frequency_config(
    config_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete frequency configuration"""
    db_config = db.query(FrequencyConfig).filter(
        FrequencyConfig.id == config_id,
        FrequencyConfig.user_id == current_user.id
    ).first()
    
    if not db_config:
        raise HTTPException(status_code=404, detail="Configuration not found")
    
    db.delete(db_config)
    db.commit()
    return {"success": True}


# ============================================================================
# API ROUTES - SESSIONS
# ============================================================================

@app.get("/api/sessions", response_model=List[SFEASessionResponse])
def list_sessions(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List user's sessions"""
    sessions = db.query(SFEASession).filter(
        SFEASession.user_id == current_user.id
    ).all()
    return sessions


@app.post("/api/sessions", response_model=SFEASessionResponse)
def create_session(
    session: SFEASessionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create new session"""
    # Verify config belongs to user
    config = db.query(FrequencyConfig).filter(
        FrequencyConfig.id == session.config_id,
        FrequencyConfig.user_id == current_user.id
    ).first()
    
    if not config:
        raise HTTPException(status_code=404, detail="Configuration not found")
    
    db_session = SFEASession(
        user_id=current_user.id,
        **session.dict()
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    return db_session


@app.get("/api/sessions/{session_id}", response_model=SFEASessionResponse)
def get_session(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get specific session"""
    session = db.query(SFEASession).filter(
        SFEASession.id == session_id,
        SFEASession.user_id == current_user.id
    ).first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return session


@app.put("/api/sessions/{session_id}", response_model=SFEASessionResponse)
def update_session(
    session_id: int,
    session_update: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update session (complete, pause, etc.)"""
    db_session = db.query(SFEASession).filter(
        SFEASession.id == session_id,
        SFEASession.user_id == current_user.id
    ).first()
    
    if not db_session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    for key, value in session_update.items():
        if hasattr(db_session, key):
            setattr(db_session, key, value)
    
    db.commit()
    db.refresh(db_session)
    return db_session


# ============================================================================
# API ROUTES - BIOFEEDBACK
# ============================================================================

@app.post("/api/biofeedback", response_model=BiofeedbackDataResponse)
def record_biofeedback(
    data: BiofeedbackDataCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Record biofeedback data point"""
    # Verify session belongs to user
    session = db.query(SFEASession).filter(
        SFEASession.id == data.session_id,
        SFEASession.user_id == current_user.id
    ).first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    db_data = BiofeedbackData(**data.dict())
    db.add(db_data)
    db.commit()
    db.refresh(db_data)
    return db_data


@app.get("/api/biofeedback/{session_id}", response_model=List[BiofeedbackDataResponse])
def get_session_biofeedback(
    session_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get biofeedback data for session"""
    # Verify session belongs to user
    session = db.query(SFEASession).filter(
        SFEASession.id == session_id,
        SFEASession.user_id == current_user.id
    ).first()
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    data = db.query(BiofeedbackData).filter(
        BiofeedbackData.session_id == session_id
    ).all()
    
    return data


# ============================================================================
# API ROUTES - CHAKRA FREQUENCIES
# ============================================================================

@app.get("/api/chakras", response_model=List[ChakraFrequencyResponse])
def list_chakra_frequencies(db: Session = Depends(get_db)):
    """List all chakra frequency mappings"""
    chakras = db.query(ChakraFrequency).all()
    
    # Seed default chakras if empty
    if not chakras:
        default_chakras = [
            {
                "name": "Root Chakra",
                "frequency_hz": 39600,
                "frequency_range": "0.1-1.5 Hz",
                "color": "#FF0000",
                "description": "Grounding, stability, survival"
            },
            {
                "name": "Sacral Chakra",
                "frequency_hz": 41700,
                "frequency_range": "1.5-3 Hz",
                "color": "#FF7F00",
                "description": "Creativity, sexuality, pleasure"
            },
            {
                "name": "Solar Plexus Chakra",
                "frequency_hz": 52800,
                "frequency_range": "3-6 Hz",
                "color": "#FFFF00",
                "description": "Power, will, transformation"
            },
            {
                "name": "Heart Chakra",
                "frequency_hz": 63900,
                "frequency_range": "6-9 Hz",
                "color": "#00FF00",
                "description": "Love, compassion, healing"
            },
            {
                "name": "Throat Chakra",
                "frequency_hz": 74100,
                "frequency_range": "9-12 Hz",
                "color": "#0000FF",
                "description": "Communication, expression, truth"
            },
            {
                "name": "Third Eye Chakra",
                "frequency_hz": 85200,
                "frequency_range": "12-15 Hz",
                "color": "#4B0082",
                "description": "Intuition, insight, clarity"
            },
            {
                "name": "Crown Chakra",
                "frequency_hz": 96300,
                "frequency_range": "15-20 Hz",
                "color": "#9400D3",
                "description": "Spirituality, enlightenment, connection"
            }
        ]
        
        for chakra_data in default_chakras:
            chakra = ChakraFrequency(**chakra_data)
            db.add(chakra)
        
        db.commit()
        chakras = db.query(ChakraFrequency).all()
    
    return chakras


# ============================================================================
# API ROUTES - DASHBOARD
# ============================================================================

@app.get("/api/dashboard/stats")
def get_dashboard_stats(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get dashboard statistics"""
    total_sessions = db.query(SFEASession).filter(
        SFEASession.user_id == current_user.id
    ).count()
    
    completed_sessions = db.query(SFEASession).filter(
        SFEASession.user_id == current_user.id,
        SFEASession.status == "completed"
    ).all()
    
    avg_coherence = 0
    if completed_sessions:
        avg_coherence = sum(s.coherence_score for s in completed_sessions) // len(completed_sessions)
    
    total_configs = db.query(FrequencyConfig).filter(
        FrequencyConfig.user_id == current_user.id
    ).count()
    
    return {
        "total_sessions": total_sessions,
        "completed_sessions": len(completed_sessions),
        "avg_coherence": avg_coherence,
        "total_configs": total_configs,
        "status": "active"
    }


# ============================================================================
# STATIC FILES & HTML ROUTES
# ============================================================================

@app.get("/", response_class=HTMLResponse)
def serve_home():
    """Serve home page"""
    return get_home_html()


@app.get("/dashboard", response_class=HTMLResponse)
def serve_dashboard():
    """Serve dashboard page"""
    return get_dashboard_html()


@app.get("/ritual", response_class=HTMLResponse)
def serve_ritual():
    """Serve ritual of intent page"""
    return get_ritual_html()


# ============================================================================
# HEALTH CHECK
# ============================================================================

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "SFEA API",
        "version": "1.0.0"
    }


# ============================================================================
# HTML TEMPLATES
# ============================================================================

def get_home_html() -> str:
    """Home page HTML"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SFEA - Supreme Frequency Engine Architect</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                background: linear-gradient(135deg, #1e1b4b 0%, #6d28d9 100%);
                color: #fff;
                min-height: 100vh;
            }
            nav {
                background: rgba(15, 23, 42, 0.8);
                padding: 1rem 2rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid rgba(168, 85, 247, 0.2);
            }
            nav h1 { font-size: 1.5rem; }
            nav a {
                background: #a855f7;
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 0.5rem;
                text-decoration: none;
                cursor: pointer;
            }
            nav a:hover { background: #9333ea; }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 4rem 2rem;
                text-align: center;
            }
            h1 { font-size: 3rem; margin-bottom: 1rem; }
            p { font-size: 1.2rem; margin-bottom: 2rem; color: #c4b5fd; }
            .features {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 2rem;
                margin: 4rem 0;
            }
            .feature-card {
                background: rgba(30, 27, 75, 0.8);
                padding: 2rem;
                border-radius: 1rem;
                border: 1px solid rgba(168, 85, 247, 0.3);
            }
            .feature-card h3 { margin-bottom: 1rem; }
            .feature-card p { color: #d8b4fe; }
            .cta-button {
                background: #a855f7;
                color: white;
                padding: 1rem 2rem;
                border: none;
                border-radius: 0.5rem;
                font-size: 1rem;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
            }
            .cta-button:hover { background: #9333ea; }
        </style>
    </head>
    <body>
        <nav>
            <h1>✨ SFEA</h1>
            <a href="/dashboard">Dashboard</a>
        </nav>
        <div class="container">
            <h1>Supreme Frequency Engine Architect</h1>
            <p>An interactive simulator for exploring the hypothetical coherence-resonance paradigm</p>
            <a href="/dashboard" class="cta-button">Enter Dashboard</a>
            
            <div class="features">
                <div class="feature-card">
                    <h3>🧠 Ritual of Intent</h3>
                    <p>Guided meditation and intention setting with breathing exercises</p>
                </div>
                <div class="feature-card">
                    <h3>⚡ Frequency Synthesis</h3>
                    <p>Multi-band frequency modulation with sacred geometry principles</p>
                </div>
                <div class="feature-card">
                    <h3>💓 Biofeedback Loop</h3>
                    <p>Real-time physiological monitoring with HRV and GSR metrics</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    """


def get_dashboard_html() -> str:
    """Dashboard page HTML"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard - SFEA</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: #f1f5f9;
                color: #1e293b;
            }
            nav {
                background: white;
                padding: 1rem 2rem;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            nav h1 { font-size: 1.5rem; }
            nav a {
                background: #a855f7;
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 0.5rem;
                text-decoration: none;
                cursor: pointer;
            }
            .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
            h2 { margin: 2rem 0 1rem 0; }
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-bottom: 2rem;
            }
            .stat-card {
                background: white;
                padding: 1.5rem;
                border-radius: 0.5rem;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            .stat-card h3 { color: #64748b; font-size: 0.9rem; margin-bottom: 0.5rem; }
            .stat-card .value { font-size: 2rem; font-weight: bold; color: #a855f7; }
            .action-cards {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
                margin-bottom: 2rem;
            }
            .action-card {
                background: white;
                padding: 2rem;
                border-radius: 0.5rem;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            .action-card h3 { margin-bottom: 1rem; }
            .action-card button {
                background: #a855f7;
                color: white;
                padding: 0.75rem 1.5rem;
                border: none;
                border-radius: 0.5rem;
                cursor: pointer;
                width: 100%;
            }
            .action-card button:hover { background: #9333ea; }
            .sessions-list {
                background: white;
                padding: 2rem;
                border-radius: 0.5rem;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            .session-item {
                padding: 1rem;
                border-bottom: 1px solid #e2e8f0;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .session-item:last-child { border-bottom: none; }
            .session-info h4 { margin-bottom: 0.25rem; }
            .session-info p { color: #64748b; font-size: 0.9rem; }
            .coherence { font-weight: bold; color: #a855f7; }
        </style>
    </head>
    <body>
        <nav>
            <h1>📊 Dashboard</h1>
            <a href="/">Home</a>
        </nav>
        <div class="container">
            <h2>Welcome to SFEA</h2>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Sessions</h3>
                    <div class="value" id="total-sessions">0</div>
                </div>
                <div class="stat-card">
                    <h3>Avg Coherence</h3>
                    <div class="value" id="avg-coherence">0%</div>
                </div>
                <div class="stat-card">
                    <h3>Configurations</h3>
                    <div class="value" id="total-configs">0</div>
                </div>
                <div class="stat-card">
                    <h3>Status</h3>
                    <div class="value" style="color: #10b981;">Active</div>
                </div>
            </div>
            
            <div class="action-cards">
                <div class="action-card">
                    <h3>🧠 Begin Ritual</h3>
                    <p>Start a new coherence session with guided breathing</p>
                    <button onclick="window.location.href='/ritual'">Start Session</button>
                </div>
                <div class="action-card">
                    <h3>⚡ Frequencies</h3>
                    <p>Manage your frequency configurations</p>
                    <button onclick="alert('Feature coming soon')">Manage Presets</button>
                </div>
            </div>
            
            <div class="sessions-list">
                <h2>Recent Sessions</h2>
                <div id="sessions-container">
                    <p style="color: #64748b;">Loading sessions...</p>
                </div>
            </div>
        </div>
        
        <script>
            async function loadDashboard() {
                try {
                    const statsRes = await fetch('/api/dashboard/stats');
                    const stats = await statsRes.json();
                    
                    document.getElementById('total-sessions').textContent = stats.total_sessions;
                    document.getElementById('avg-coherence').textContent = stats.avg_coherence + '%';
                    document.getElementById('total-configs').textContent = stats.total_configs;
                    
                    const sessionsRes = await fetch('/api/sessions');
                    const sessions = await sessionsRes.json();
                    
                    const container = document.getElementById('sessions-container');
                    if (sessions.length === 0) {
                        container.innerHTML = '<p style="color: #64748b;">No sessions yet. Begin your first Ritual of Intent.</p>';
                    } else {
                        container.innerHTML = sessions.map(s => `
                            <div class="session-item">
                                <div class="session-info">
                                    <h4>${s.intention}</h4>
                                    <p>${new Date(s.created_at).toLocaleDateString()} • ${s.duration_seconds}s</p>
                                </div>
                                <div class="coherence">${s.coherence_score}%</div>
                            </div>
                        `).join('');
                    }
                } catch (error) {
                    console.error('Error loading dashboard:', error);
                }
            }
            
            loadDashboard();
        </script>
    </body>
    </html>
    """


def get_ritual_html() -> str:
    """Ritual of Intent page HTML"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ritual of Intent - SFEA</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: linear-gradient(135deg, #1e1b4b 0%, #6d28d9 100%);
                color: #fff;
                min-height: 100vh;
            }
            nav {
                background: rgba(15, 23, 42, 0.8);
                padding: 1rem 2rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid rgba(168, 85, 247, 0.2);
            }
            nav a {
                background: #a855f7;
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 0.5rem;
                text-decoration: none;
            }
            .container { max-width: 600px; margin: 0 auto; padding: 2rem; }
            .card {
                background: rgba(30, 27, 75, 0.8);
                padding: 2rem;
                border-radius: 1rem;
                border: 1px solid rgba(168, 85, 247, 0.3);
            }
            h2 { margin-bottom: 1rem; }
            .form-group {
                margin-bottom: 1.5rem;
            }
            label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: 500;
            }
            input, textarea, select {
                width: 100%;
                padding: 0.75rem;
                border: 1px solid rgba(168, 85, 247, 0.3);
                border-radius: 0.5rem;
                background: rgba(255, 255, 255, 0.1);
                color: white;
                font-family: inherit;
            }
            input::placeholder, textarea::placeholder {
                color: rgba(255, 255, 255, 0.5);
            }
            button {
                width: 100%;
                padding: 1rem;
                background: #a855f7;
                color: white;
                border: none;
                border-radius: 0.5rem;
                font-size: 1rem;
                cursor: pointer;
                margin-top: 1rem;
            }
            button:hover { background: #9333ea; }
            
            .breathing-circle {
                width: 200px;
                height: 200px;
                border: 4px solid #a855f7;
                border-radius: 50%;
                margin: 2rem auto;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2rem;
                font-weight: bold;
                animation: breathe 12s infinite;
            }
            @keyframes breathe {
                0%, 100% { transform: scale(1); opacity: 1; }
                33% { transform: scale(1.1); opacity: 0.8; }
                66% { transform: scale(1.05); opacity: 0.9; }
            }
            
            .hidden { display: none; }
            .phase-title { text-align: center; margin-bottom: 2rem; }
        </style>
    </head>
    <body>
        <nav>
            <h1>🧘 Ritual of Intent</h1>
            <a href="/dashboard">Back</a>
        </nav>
        
        <div class="container">
            <!-- Phase 1: Intention Setting -->
            <div id="phase1" class="card">
                <div class="phase-title">
                    <h2>Set Your Intention</h2>
                    <p>Define your desired state of coherence</p>
                </div>
                
                <div class="form-group">
                    <label>Select Frequency Configuration</label>
                    <select id="config-select">
                        <option value="">Loading configurations...</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Intention Statement</label>
                    <textarea id="intention-input" placeholder="e.g., I seek deep internal coherence and peace" rows="4"></textarea>
                </div>
                
                <div class="form-group" id="chakras-container"></div>
                
                <button onclick="startBreathing()">Begin Breathing Exercise</button>
            </div>
            
            <!-- Phase 2: Breathing Exercise -->
            <div id="phase2" class="card hidden">
                <div class="phase-title">
                    <h2>Guided Breathing</h2>
                    <p>Follow the rhythm to synchronize with the field</p>
                </div>
                
                <div class="breathing-circle" id="breathing-circle">Inhale</div>
                
                <div style="text-align: center;">
                    <p id="breathing-time">60s remaining</p>
                    <div style="background: rgba(255,255,255,0.1); height: 4px; border-radius: 2px; margin: 1rem 0;">
                        <div id="progress-bar" style="height: 100%; background: #a855f7; width: 0%; border-radius: 2px;"></div>
                    </div>
                </div>
            </div>
            
            <!-- Phase 3: Session Activation -->
            <div id="phase3" class="card hidden">
                <div class="phase-title">
                    <h2>Session Ready</h2>
                </div>
                
                <div style="background: rgba(255,255,255,0.1); padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                    <p style="color: #c4b5fd; margin-bottom: 0.5rem;">Your Intention:</p>
                    <p id="intention-display" style="font-weight: bold;"></p>
                </div>
                
                <button onclick="activateSession()">Activate Coherence Field</button>
                <button onclick="resetRitual()" style="background: #6b7280; margin-top: 0.5rem;">Back to Setup</button>
            </div>
        </div>
        
        <script>
            let breathingInterval = null;
            let breathingTime = 0;
            
            async function loadConfigs() {
                try {
                    const res = await fetch('/api/frequencies');
                    const configs = await res.json();
                    
                    const select = document.getElementById('config-select');
                    select.innerHTML = configs.length > 0 
                        ? configs.map(c => `<option value="${c.id}">${c.name}</option>`).join('')
                        : '<option value="">No configurations available</option>';
                } catch (error) {
                    console.error('Error loading configs:', error);
                }
            }
            
            async function loadChakras() {
                try {
                    const res = await fetch('/api/chakras');
                    const chakras = await res.json();
                    
                    const container = document.getElementById('chakras-container');
                    container.innerHTML = '<label>Chakra Frequency Map</label><div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.5rem;">' +
                        chakras.map(c => `
                            <div style="padding: 0.75rem; background: rgba(255,255,255,0.1); border-radius: 0.5rem; display: flex; align-items: center; gap: 0.5rem;">
                                <div style="width: 12px; height: 12px; background: ${c.color}; border-radius: 50%;"></div>
                                <div>
                                    <div style="font-weight: 500; font-size: 0.9rem;">${c.name}</div>
                                    <div style="color: #c4b5fd; font-size: 0.8rem;">${c.frequency_range}</div>
                                </div>
                            </div>
                        `).join('') +
                    '</div>';
                } catch (error) {
                    console.error('Error loading chakras:', error);
                }
            }
            
            function startBreathing() {
                const intention = document.getElementById('intention-input').value;
                const configId = document.getElementById('config-select').value;
                
                if (!intention || !configId) {
                    alert('Please select a configuration and enter an intention');
                    return;
                }
                
                document.getElementById('intention-display').textContent = intention;
                document.getElementById('phase1').classList.add('hidden');
                document.getElementById('phase2').classList.remove('hidden');
                
                breathingTime = 0;
                breathingInterval = setInterval(() => {
                    breathingTime++;
                    const remaining = 60 - breathingTime;
                    document.getElementById('breathing-time').textContent = remaining + 's remaining';
                    document.getElementById('progress-bar').style.width = (breathingTime / 60 * 100) + '%';
                    
                    const cycle = breathingTime % 12;
                    const circle = document.getElementById('breathing-circle');
                    if (cycle < 4) circle.textContent = 'Inhale';
                    else if (cycle < 8) circle.textContent = 'Hold';
                    else circle.textContent = 'Exhale';
                    
                    if (breathingTime >= 60) {
                        clearInterval(breathingInterval);
                        document.getElementById('phase2').classList.add('hidden');
                        document.getElementById('phase3').classList.remove('hidden');
                    }
                }, 1000);
            }
            
            async function activateSession() {
                const intention = document.getElementById('intention-input').value;
                const configId = document.getElementById('config-select').value;
                
                try {
                    const res = await fetch('/api/sessions', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ config_id: parseInt(configId), intention })
                    });
                    
                    if (res.ok) {
                        alert('Session created successfully!');
                        window.location.href = '/dashboard';
                    }
                } catch (error) {
                    console.error('Error creating session:', error);
                }
            }
            
            function resetRitual() {
                document.getElementById('phase1').classList.remove('hidden');
                document.getElementById('phase2').classList.add('hidden');
                document.getElementById('phase3').classList.add('hidden');
                document.getElementById('intention-input').value = '';
                if (breathingInterval) clearInterval(breathingInterval);
            }
            
            // Load data on page load
            loadConfigs();
            loadChakras();
        </script>
    </body>
    </html>
    """


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    print("""
    ╔════════════════════════════════════════════════════════════════╗
    ║  Supreme Frequency Engine Architect (SFEA) - Python Edition    ║
    ║  Starting server...                                            ║
    ║  Access at: http://localhost:8000                             ║
    ║  API Docs: http://localhost:8000/docs                         ║
    ╚════════════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
